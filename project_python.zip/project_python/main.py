import requests
from bs4 import BeautifulSoup
import csv
from itertools import zip_longest
url='https://www.amazon.eg/-/en/New-Apple-iPhone-Facetime-128GB/dp/B09G8Y5W7V/ref=sr_1_1?adgrpid=136906000046&gclid=CjwKCAiAy_CcBhBeEiwAcoMRHPhma92uwBf3d-qQ9fWGUF_9lMpZ-iSGm7mY1HsY71FQSTDIxS21HRoCpVQQAvD_BwE&hvadid=636086272291&hvdev=c&hvlocphy=1005388&hvnetw=g&hvqmt=e&hvrand=9262667160978383633&hvtargid=kwd-1574597182517&hydadcr=22125_2261760&keywords=%D8%A7%D9%8A%D9%81%D9%88%D9%86%2B13%2B%D8%A8%D8%B1%D9%88%2B%D8%A7%D9%85%D8%A7%D8%B2%D9%88%D9%86&qid=1671207100&sr=8-1&th=1'
result=requests.get(url)
source=result.content
print(source)
soup=BeautifulSoup(source,"html.parser")
print(soup)
name=soup.find(id="title").get_text().replace('\n',' ')
print(name)
brand=soup.find(class_="a-spacing-small po-brand").get_text().replace('\n',' ')
print(brand)
model_name=soup.find(class_="a-spacing-small po-model_name").get_text().replace('\n',' ')
print(model_name)
price=soup.find(class_="a-offscreen").get_text().replace('\n',' ')
print(price)
size=soup.find(class_="a-spacing-small po-display.size").get_text().replace('\n',' ')
print(size)
details=soup.find(id="detailBullets_feature_div").get_text().replace('\n',' ')
print(details)
more_details=soup.find(id="feature-bullets").get_text().replace('\n',' ')
print(details)
color=soup.find(class_="a-spacing-small po-color").get_text().replace('\n',' ')
print(color)
operating=soup.find(class_="a-spacing-small po-operating_system").get_text().replace('\n',' ')
print(operating)
#overview=soup.find(class_="aplus-module-wrapper aplus-3p-fixed-width").get_text().replace('\n',' ')
#print(overview)
other_items=soup.findAll('li',{'class':'a-spacing-small po-brand'})
print(other_items)





